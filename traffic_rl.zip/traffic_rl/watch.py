"""Opens the SUMO window and watches a controller run.

    python watch.py                       trained agent on the training demand
    python watch.py reversed              trained agent on another scenario
    python watch.py heavy greedy          a baseline instead, for comparison
    python watch.py training fixed
"""

import sys

from agent import DQNAgent
from env import TrafficEnv

scenario = sys.argv[1] if len(sys.argv) > 1 else "training"
which = sys.argv[2] if len(sys.argv) > 2 else "dqn"


class Greedy:
    def act(self, obs):
        return 0 if obs[0] + obs[1] >= obs[2] + obs[3] else 1


class FixedTime:
    def __init__(self):
        self.action, self.counter = 0, 0

    def act(self, obs):
        self.counter += 1
        limit = 5 if self.action == 0 else 2
        if self.counter >= limit:
            self.action, self.counter = 1 - self.action, 0
        return self.action


class Trained:
    def __init__(self, path="results/seeds/agent_seed0.pt"):
        self.agent = DQNAgent()
        self.agent.load(path)
        self.q = None

    def act(self, obs):
        self.q = self.agent.q_values(obs)
        return 0 if self.q[0] >= self.q[1] else 1


controller = {"dqn": Trained, "greedy": Greedy, "fixed": FixedTime}[which]()

env = TrafficEnv(gui=True, gui_delay=120,
                 config=f"sumo_files/scenarios/{scenario}.sumocfg")
obs, _ = env.reset()

print(f"watching '{which}' on the '{scenario}' scenario")
print("close the SUMO window or press Ctrl+C to stop\n")
print(f"{'time':>6}  {'N':>4} {'S':>4} {'E':>4} {'W':>4}   "
      f"{'Q(n/s)':>8} {'Q(e/w)':>8}  green")

step, done = 0, False
try:
    while not done:
        action = controller.act(obs)
        obs, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated
        step += 1
        if step % 4 == 0:
            q = info["queues"]
            axis = "north/south" if action == 0 else "east/west"
            if getattr(controller, "q", None) is not None:
                qn, qe = controller.q
                marker = "  <--" if abs(qn - qe) < 0.05 else ""
                print(f"{step*5:6d}  {q[0]:4d} {q[1]:4d} {q[2]:4d} {q[3]:4d}   "
                      f"{qn:8.2f} {qe:8.2f}  {axis}{marker}")
            else:
                print(f"{step*5:6d}  {q[0]:4d} {q[1]:4d} {q[2]:4d} {q[3]:4d}   "
                      f"{'':>8} {'':>8}  {axis}")
except KeyboardInterrupt:
    print("\nstopped")
finally:
    env.close()
