import random
from collections import deque

import numpy as np
import torch
import torch.nn as nn


class QNetwork(nn.Module):
    def __init__(self, n_obs, n_actions, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_obs, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, n_actions),
        )

    def forward(self, x):
        return self.net(x)


class ReplayBuffer:
    def __init__(self, capacity=50000):
        self.buffer = deque(maxlen=capacity)

    def add(self, obs, action, reward, next_obs, done):
        self.buffer.append((obs, action, reward, next_obs, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        obs, action, reward, next_obs, done = zip(*batch)
        return (torch.tensor(np.array(obs), dtype=torch.float32),
                torch.tensor(action, dtype=torch.int64),
                torch.tensor(reward, dtype=torch.float32),
                torch.tensor(np.array(next_obs), dtype=torch.float32),
                torch.tensor(done, dtype=torch.float32))

    def __len__(self):
        return len(self.buffer)


class DQNAgent:
    def __init__(self, n_obs=7, n_actions=2, lr=1e-3, gamma=0.95,
                 batch_size=64, target_update=500, seed=0):
        torch.manual_seed(seed)
        random.seed(seed)

        self.n_actions = n_actions
        self.gamma = gamma
        self.batch_size = batch_size
        self.target_update = target_update

        self.online = QNetwork(n_obs, n_actions)
        self.target = QNetwork(n_obs, n_actions)
        self.target.load_state_dict(self.online.state_dict())

        self.optimiser = torch.optim.Adam(self.online.parameters(), lr=lr)
        self.buffer = ReplayBuffer()
        self.learn_steps = 0

        self.epsilon = 1.0
        self.epsilon_min = 0.05
        self.epsilon_decay = 0.9995

    def act(self, obs, explore=True):
        if explore and random.random() < self.epsilon:
            return random.randrange(self.n_actions)
        with torch.no_grad():
            q = self.online(torch.tensor(obs, dtype=torch.float32).unsqueeze(0))
        return int(q.argmax().item())

    def q_values(self, obs):
        """The network's estimate of future reward for each action."""
        with torch.no_grad():
            q = self.online(torch.tensor(obs, dtype=torch.float32).unsqueeze(0))
        return q.squeeze(0).tolist()

    def remember(self, obs, action, reward, next_obs, done):
        self.buffer.add(obs, action, reward, next_obs, done)

    def learn(self):
        if len(self.buffer) < self.batch_size:
            return None

        obs, action, reward, next_obs, done = self.buffer.sample(self.batch_size)

        q = self.online(obs).gather(1, action.unsqueeze(1)).squeeze(1)
        with torch.no_grad():
            next_q = self.target(next_obs).max(dim=1)[0]
            target = reward + self.gamma * next_q * (1 - done)

        loss = nn.functional.smooth_l1_loss(q, target)
        self.optimiser.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.online.parameters(), 10.0)
        self.optimiser.step()

        self.learn_steps += 1
        if self.learn_steps % self.target_update == 0:
            self.target.load_state_dict(self.online.state_dict())

        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return float(loss.item())

    def save(self, path):
        torch.save(self.online.state_dict(), path)

    def load(self, path):
        self.online.load_state_dict(torch.load(path))
        self.target.load_state_dict(self.online.state_dict())
