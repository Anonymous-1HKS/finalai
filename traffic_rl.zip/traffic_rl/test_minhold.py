import xml.etree.ElementTree as ET
from agent import DQNAgent
from env import TrafficEnv


class MinHold:
    def __init__(self, inner, hold):
        self.inner, self.hold = inner, hold
        self.current, self.since = 0, 99

    def act(self, obs):
        want = self.inner(obs)
        if want != self.current and self.since >= self.hold:
            self.current, self.since = want, 0
        else:
            self.since += 1
        return self.current


agent = DQNAgent(); agent.load("results/random_agent.pt")
policy = lambda obs: agent.act(obs, explore=False)
greedy = lambda obs: 0 if obs[0] + obs[1] >= obs[2] + obs[3] else 1


def run(controller, scenario):
    tp = f"results/mh_{scenario}.xml"
    env = TrafficEnv(config=f"sumo_files/scenarios/{scenario}.sumocfg", tripinfo=tp)
    obs, _ = env.reset(); done = False; sw = 0; last = 0
    while not done:
        a = controller.act(obs)
        if a != last: sw += 1; last = a
        obs, r, term, trunc, _ = env.step(a); done = term or trunc
    env.close()
    w = [float(t.get("waitingTime")) for t in ET.parse(tp).getroot().findall("tripinfo")]
    return sum(w)/len(w), max(w), len(w), sw


for scenario in ["heavy", "training", "light"]:
    print(f"--- {scenario} ---")
    for hold in [0, 2, 3, 4, 6]:
        m, mx, n, sw = run(MinHold(policy, hold), scenario)
        print(f"  DQN, min green {hold*5:2d}s | wait {m:6.1f} | max {mx:5.1f} | veh {n:5d} | switches {sw:4d}")
    m, mx, n, sw = run(MinHold(greedy, 3), scenario)
    print(f"  Greedy, min green 15s | wait {m:6.1f} | max {mx:5.1f} | veh {n:5d} | switches {sw:4d}")
