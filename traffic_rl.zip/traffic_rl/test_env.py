import xml.etree.ElementTree as ET
from env import TrafficEnv


def greedy(obs):
    ns = obs[0] + obs[1]
    ew = obs[2] + obs[3]
    return 0 if ns >= ew else 1


env = TrafficEnv(tripinfo="results/env_trip.xml")
obs, info = env.reset()

total_reward = 0.0
steps = 0
while True:
    obs, reward, terminated, truncated, info = env.step(greedy(obs))
    total_reward += reward
    steps += 1
    if terminated or truncated:
        break
env.close()

waits = [float(t.get("waitingTime"))
         for t in ET.parse("results/env_trip.xml").getroot().findall("tripinfo")]

print("steps in episode:", steps)
print("total reward:    ", round(total_reward, 1))
print("vehicles:        ", len(waits))
print("mean wait:        %.1f s" % (sum(waits) / len(waits)))
