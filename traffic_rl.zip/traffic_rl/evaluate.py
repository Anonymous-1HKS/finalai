import os
import xml.etree.ElementTree as ET

from agent import DQNAgent
from env import TrafficEnv

SCENARIOS = ["heavy", "training", "light"]
os.makedirs("results", exist_ok=True)


class FixedTime:
    name = "Fixed time 25/10"

    def __init__(self):
        self.action, self.counter = 0, 0

    def act(self, obs):
        self.counter += 1
        limit = 5 if self.action == 0 else 2
        if self.counter >= limit:
            self.action = 1 - self.action
            self.counter = 0
        return self.action


class Greedy:
    name = "Greedy"

    def act(self, obs):
        return 0 if obs[0] + obs[1] >= obs[2] + obs[3] else 1


class TrainedAgent:
    def __init__(self, path="results/best_agent.pt", name="DQN"):
        self.name = name
        self.agent = DQNAgent()
        self.agent.load(path)

    def act(self, obs):
        return self.agent.act(obs, explore=False)


def run(controller, scenario):
    tripinfo = f"results/eval_{scenario}.xml"
    env = TrafficEnv(config=f"sumo_files/scenarios/{scenario}.sumocfg",
                     tripinfo=tripinfo)
    obs, _ = env.reset()
    done = False
    switches = 0
    last = 0
    while not done:
        action = controller.act(obs)
        if action != last:
            switches += 1
            last = action
        obs, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
    env.close()

    waits = [float(t.get("waitingTime"))
             for t in ET.parse(tripinfo).getroot().findall("tripinfo")]
    return sum(waits) / len(waits), max(waits), len(waits), switches


print(f"{'scenario':<12}{'controller':<22}{'mean wait':>10}{'max wait':>10}{'vehicles':>10}{'switches':>10}")
print("-" * 76)

for scenario in SCENARIOS:
    builders = [FixedTime, Greedy,
                lambda: TrainedAgent("results/best_agent.pt", "DQN (fixed demand)"),
                lambda: TrainedAgent("results/random_agent.pt", "DQN (randomised)")]
    for build in builders:
        controller = build()
        mean, mx, n, sw = run(controller, scenario)
        print(f"{scenario:<12}{controller.name:<22}{mean:10.1f}{mx:10.1f}{n:10d}{sw:10d}")
    print()
