class FixedTimeController:
    def __init__(self, steps_major=5, steps_minor=2):
        self.steps_major = steps_major
        self.steps_minor = steps_minor
        self.action = 0
        self.counter = 0

    def act(self, queues):
        self.counter += 1
        limit = self.steps_major if self.action == 0 else self.steps_minor
        if self.counter >= limit:
            self.action = 1 - self.action
            self.counter = 0
        return self.action


class GreedyController:

    def act(self, queues):
        ns = queues[0] + queues[1]
        ew = queues[2] + queues[3]
        return 0 if ns >= ew else 1


class RandomController:
    def __init__(self, seed=0):
        import random
        self.rng = random.Random(seed)

    def act(self, queues):
        return self.rng.randint(0, 1)
