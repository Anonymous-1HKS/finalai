import os
import numpy as np
import gymnasium as gym
from gymnasium import spaces
import traci

CONFIG = "sumo_files/intersection.sumocfg"
TLS_ID = "center"

APPROACH_LANES = [
    ["north_in_1", "north_in_2"],
    ["south_in_1", "south_in_2"],
    ["east_in_1", "east_in_2"],
    ["west_in_1", "west_in_2"],
]
ALL_LANES = [lane for lanes in APPROACH_LANES for lane in lanes]

GREEN_PHASE = {0: 0, 1: 2}
YELLOW_PHASE = {0: 1, 1: 3}

DECISION_INTERVAL = 5
YELLOW_TIME = 3
EPISODE_SECONDS = 3600

MAX_QUEUE = 30.0          # for normalising the observation
MAX_SINCE_SWITCH = 60.0


class TrafficEnv(gym.Env):

    def __init__(self, gui=False, tripinfo=None, config=CONFIG, randomize=False,
                 gui_delay=80):
        super().__init__()
        self.gui = gui
        self.gui_delay = gui_delay
        self.tripinfo = tripinfo
        self.config = config
        self.randomize = randomize
        self.demand = None

        self.action_space = spaces.Discrete(2)
        self.observation_space = spaces.Box(low=0.0, high=1.0,
                                            shape=(7,), dtype=np.float32)
        self.running = False

    def _queues(self):
        return [sum(traci.lane.getLastStepHaltingNumber(l) for l in lanes)
                for lanes in APPROACH_LANES]

    def _total_waiting(self):
        total = 0.0
        for lane in ALL_LANES:
            for v in traci.lane.getLastStepVehicleIDs(lane):
                total += traci.vehicle.getAccumulatedWaitingTime(v)
        return total

    def _observation(self):
        q = [min(x / MAX_QUEUE, 1.0) for x in self._queues()]
        phase = [1.0 if self.action == 0 else 0.0,
                 1.0 if self.action == 1 else 0.0]
        since = min(self.since_switch / MAX_SINCE_SWITCH, 1.0)
        return np.array(q + phase + [since], dtype=np.float32)

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        if self.running:
            traci.close()

        if self.randomize:
            from demand import write_demand, random_demand, CONFIG as CFG
            ns, ew, turn = random_demand(self.np_random)
            self.demand = (int(ns), int(ew), int(turn))
            write_demand("sumo_files/random.rou.xml", ns, ew, turn)
            open("sumo_files/random.sumocfg", "w").write(
                CFG.format(routes="random.rou.xml"))
            self.config = "sumo_files/random.sumocfg"

        binary = "sumo-gui" if self.gui else "sumo"
        cmd = [binary, "-c", self.config, "--no-step-log", "--no-warnings"]
        if self.gui:
            cmd += ["--start", "--quit-on-end", "--delay", str(self.gui_delay)]
        if self.tripinfo:
            os.makedirs(os.path.dirname(self.tripinfo), exist_ok=True)
            cmd += ["--tripinfo-output", self.tripinfo]
        traci.start(cmd)
        self.running = True

        self.action = 0
        self.since_switch = 0.0
        traci.trafficlight.setPhase(TLS_ID, GREEN_PHASE[self.action])
        self.previous_waiting = 0.0

        return self._observation(), {}

    def step(self, action):
        action = int(action)

        if action != self.action:
            traci.trafficlight.setPhase(TLS_ID, YELLOW_PHASE[self.action])
            for _ in range(YELLOW_TIME):
                traci.simulationStep()
            self.action = action
            self.since_switch = 0.0
        else:
            self.since_switch += DECISION_INTERVAL

        traci.trafficlight.setPhase(TLS_ID, GREEN_PHASE[self.action])
        for _ in range(DECISION_INTERVAL):
            traci.simulationStep()

        waiting = self._total_waiting()
        reward = self.previous_waiting - waiting
        self.previous_waiting = waiting

        terminated = False
        truncated = traci.simulation.getTime() >= EPISODE_SECONDS
        info = {"queues": self._queues(), "total_waiting": waiting}

        return self._observation(), reward, terminated, truncated, info

    def close(self):
        if self.running:
            traci.close()
            self.running = False
