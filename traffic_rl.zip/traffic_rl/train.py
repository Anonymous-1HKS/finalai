import os
import time
import xml.etree.ElementTree as ET

from agent import DQNAgent
from env import TrafficEnv

EPISODES = 30
REWARD_SCALE = 100.0
os.makedirs("results", exist_ok=True)


def mean_wait(path):
    waits = [float(t.get("waitingTime"))
             for t in ET.parse(path).getroot().findall("tripinfo")]
    return sum(waits) / len(waits), len(waits)


env = TrafficEnv(tripinfo="results/train_trip.xml")
agent = DQNAgent()

print(f"{'episode':>7} {'mean wait':>10} {'vehicles':>9} {'epsilon':>8} {'seconds':>8}")

history = []
best = float("inf")

for episode in range(1, EPISODES + 1):
    start = time.time()
    obs, _ = env.reset()
    done = False

    while not done:
        action = agent.act(obs)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        agent.remember(obs, action, reward / REWARD_SCALE, next_obs, float(done))
        agent.learn()
        obs = next_obs

    env.close()          # closing flushes the tripinfo file to disk
    wait, vehicles = mean_wait("results/train_trip.xml")
    history.append(wait)
    if wait < best:
        best = wait
        agent.save("results/best_agent.pt")

    print(f"{episode:7d} {wait:10.1f} {vehicles:9d} "
          f"{agent.epsilon:8.3f} {time.time()-start:8.1f}")

agent.save("results/final_agent.pt")

with open("results/training_history.txt", "w") as f:
    for i, w in enumerate(history, 1):
        f.write(f"{i}\t{w:.2f}\n")

print("\nbest mean wait:", round(best, 1), "s")
