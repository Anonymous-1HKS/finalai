ROUTES = """<routes>
    <vType id="car" accel="2.6" decel="4.5" length="5" maxSpeed="16"/>
    <route id="ns" edges="north_in south_out"/>
    <route id="sn" edges="south_in north_out"/>
    <route id="ew" edges="east_in  west_out"/>
    <route id="we" edges="west_in  east_out"/>
    <route id="nw" edges="north_in west_out"/>
    <route id="se" edges="south_in east_out"/>
    <route id="en" edges="east_in  north_out"/>
    <route id="ws" edges="west_in  south_out"/>
    <flow id="f_ns" type="car" route="ns" begin="0" end="3600" vehsPerHour="{ns}"/>
    <flow id="f_sn" type="car" route="sn" begin="0" end="3600" vehsPerHour="{ns}"/>
    <flow id="f_ew" type="car" route="ew" begin="0" end="3600" vehsPerHour="{ew}"/>
    <flow id="f_we" type="car" route="we" begin="0" end="3600" vehsPerHour="{ew}"/>
    <flow id="f_nw" type="car" route="nw" begin="0" end="3600" vehsPerHour="{turn}"/>
    <flow id="f_se" type="car" route="se" begin="0" end="3600" vehsPerHour="{turn}"/>
    <flow id="f_en" type="car" route="en" begin="0" end="3600" vehsPerHour="{turn}"/>
    <flow id="f_ws" type="car" route="ws" begin="0" end="3600" vehsPerHour="{turn}"/>
</routes>
"""

CONFIG = """<configuration>
    <input>
        <net-file value="intersection.net.xml"/>
        <route-files value="{routes}"/>
    </input>
    <time><begin value="0"/><end value="3600"/></time>
</configuration>
"""


def write_demand(route_path, ns, ew, turn):
    open(route_path, "w").write(ROUTES.format(ns=int(ns), ew=int(ew), turn=int(turn)))


def random_demand(rng):
    heavy = rng.integers(600, 2000)
    light = rng.integers(200, max(201, heavy))
    turn = rng.integers(80, 220)
    if rng.random() < 0.5:
        return heavy, light, turn      # north/south busy
    return light, heavy, turn          # east/west busy
