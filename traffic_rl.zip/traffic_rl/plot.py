import os
import glob
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.makedirs("results/figures", exist_ok=True)


def read_history(path):
    return [float(line.split("\t")[1]) for line in open(path) if line.strip()]

files = sorted(glob.glob("results/seeds/history_seed*.txt"))
if files:
    plt.figure(figsize=(7, 4))
    for path in files:
        seed = path.split("seed")[-1].split(".")[0]
        plt.plot(range(1, len(read_history(path)) + 1), read_history(path),
                 alpha=0.7, label=f"seed {seed}")
    plt.xlabel("Episode")
    plt.ylabel("Mean waiting time (s)")
    plt.title("DQN training on randomised demand")
    plt.legend(fontsize=8)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("results/figures/training_curves.png", dpi=150)
    plt.close()
    print("wrote training_curves.png")

summary = "results/seed_summary.txt"
if os.path.exists(summary):
    lines = [l.strip().split("\t") for l in open(summary)][1:]
    scenarios = [l[0] for l in lines]
    fixed = [float(l[1]) for l in lines]
    greedy = [float(l[2]) for l in lines]
    dqn = [float(l[3]) for l in lines]
    err = [float(l[4]) for l in lines]

    x = range(len(scenarios))
    width = 0.27
    plt.figure(figsize=(8, 4.5))
    plt.bar([i - width for i in x], fixed, width, label="Fixed time")
    plt.bar(list(x), greedy, width, label="Greedy")
    plt.bar([i + width for i in x], dqn, width, yerr=err, capsize=4,
            label="DQN (5 seeds)")
    plt.xticks(list(x), scenarios)
    plt.ylabel("Mean waiting time (s)")
    plt.title("Controller comparison across demand scenarios")
    plt.legend()
    plt.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig("results/figures/comparison.png", dpi=150)
    plt.close()
    print("wrote comparison.png")

print("figures are in results/figures/")
