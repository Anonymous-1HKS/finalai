import traci

SUMO_BINARY = "sumo"
CONFIG = "sumo_files/intersection.sumocfg"

CONTROLLED_LANES = {
    "north": ["north_in_1", "north_in_2"],
    "south": ["south_in_1", "south_in_2"],
    "east":  ["east_in_1",  "east_in_2"],
    "west":  ["west_in_1",  "west_in_2"],
}

TLS_ID = "center"


def queue_on(lane_ids):
    return sum(traci.lane.getLastStepHaltingNumber(lane) for lane in lane_ids)

traci.start([SUMO_BINARY, "-c", CONFIG])

logic = traci.trafficlight.getAllProgramLogics(TLS_ID)[0]
print("Traffic light programme has", len(logic.phases), "phases:")
for i, phase in enumerate(logic.phases):
    print("  phase", i, "state:", phase.state, " default duration:", phase.duration)

print()
print(" time |  north  south   east   west | phase")

for step in range(3600):
    traci.simulationStep()

    if step % 60 == 0:
        n = queue_on(CONTROLLED_LANES["north"])
        s = queue_on(CONTROLLED_LANES["south"])
        e = queue_on(CONTROLLED_LANES["east"])
        w = queue_on(CONTROLLED_LANES["west"])
        phase = traci.trafficlight.getPhase(TLS_ID)
        print(f"{step:5d} | {n:6d} {s:6d} {e:6d} {w:6d} | {phase}")

traci.close()
print("done")
