import os, time
import xml.etree.ElementTree as ET

from agent import DQNAgent
from env import TrafficEnv

EPISODES = 60
REWARD_SCALE = 100.0
os.makedirs("results", exist_ok=True)

env = TrafficEnv(tripinfo="results/train_trip.xml", randomize=True)
agent = DQNAgent()

print(f"{'ep':>4} {'ns':>5} {'ew':>5} {'mean wait':>10} {'vehicles':>9} {'eps':>6} {'s':>5}")

history = []
for episode in range(1, EPISODES + 1):
    start = time.time()
    obs, _ = env.reset(seed=episode)
    done = False
    while not done:
        action = agent.act(obs)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        agent.remember(obs, action, reward / REWARD_SCALE, next_obs, float(done))
        agent.learn()
        obs = next_obs
    env.close()

    waits = [float(t.get("waitingTime")) for t in
             ET.parse("results/train_trip.xml").getroot().findall("tripinfo")]
    wait = sum(waits) / len(waits)
    history.append(wait)
    ns, ew, turn = env.demand
    print(f"{episode:4d} {ns:5d} {ew:5d} {wait:10.1f} {len(waits):9d} "
          f"{agent.epsilon:6.3f} {time.time()-start:5.1f}")

agent.save("results/random_agent.pt")
with open("results/random_history.txt", "w") as f:
    for i, w in enumerate(history, 1):
        f.write(f"{i}\t{w:.2f}\n")
print("\nsaved results/random_agent.pt")
