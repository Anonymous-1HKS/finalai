import xml.etree.ElementTree as ET
import traci

CONFIG = "sumo_files/intersection.sumocfg"
TLS_ID = "center"

APPROACH_LANES = [
    ["north_in_1", "north_in_2"],
    ["south_in_1", "south_in_2"],
    ["east_in_1", "east_in_2"],
    ["west_in_1", "west_in_2"],
]

GREEN_PHASE = {0: 0, 1: 2}      # action -> phase index in the SUMO programme
YELLOW_PHASE = {0: 1, 1: 3}     # action being left -> the yellow that follows it

DECISION_INTERVAL = 5
YELLOW_TIME = 3
EPISODE_SECONDS = 3600


def read_queues():
    return [sum(traci.lane.getLastStepHaltingNumber(l) for l in lanes)
            for lanes in APPROACH_LANES]


def run_episode(controller, gui=False, tripinfo="results/trip.xml"):
    binary = "sumo-gui" if gui else "sumo"
    traci.start([binary, "-c", CONFIG, "--no-step-log", "--no-warnings",
                 "--tripinfo-output", tripinfo])

    current_action = 0
    traci.trafficlight.setPhase(TLS_ID, GREEN_PHASE[current_action])

    queue_samples = []
    switches = 0

    while traci.simulation.getTime() < EPISODE_SECONDS:
        queues = read_queues()
        queue_samples.append(sum(queues))
        action = controller.act(queues)

        if action != current_action:
            switches += 1
            traci.trafficlight.setPhase(TLS_ID, YELLOW_PHASE[current_action])
            for _ in range(YELLOW_TIME):
                traci.simulationStep()
            current_action = action
            traci.trafficlight.setPhase(TLS_ID, GREEN_PHASE[current_action])
            remaining = DECISION_INTERVAL
        else:
            traci.trafficlight.setPhase(TLS_ID, GREEN_PHASE[current_action])
            remaining = DECISION_INTERVAL

        for _ in range(remaining):
            traci.simulationStep()

    traci.close()

    waits = [float(t.get("waitingTime"))
             for t in ET.parse(tripinfo).getroot().findall("tripinfo")]

    return {
        "vehicles": len(waits),
        "mean_wait": sum(waits) / len(waits),
        "max_wait": max(waits),
        "mean_queue": sum(queue_samples) / len(queue_samples),
        "peak_queue": max(queue_samples),
        "switches": switches,
    }
