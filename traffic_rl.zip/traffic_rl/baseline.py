from simulation import run_episode
from controllers import FixedTimeController, GreedyController, RandomController

RUNS = [
    ("Fixed time 25/10", FixedTimeController(5, 2)),
    ("Fixed time 25/25", FixedTimeController(5, 5)),
    ("Greedy (longest queue)", GreedyController()),
    ("Random", RandomController(seed=0)),
]

print(f"{'controller':<24} {'vehicles':>9} {'mean wait':>10} {'max wait':>9} "
      f"{'mean queue':>11} {'switches':>9}")
print("-" * 78)

for name, controller in RUNS:
    r = run_episode(controller)
    print(f"{name:<24} {r['vehicles']:9d} {r['mean_wait']:10.1f} "
          f"{r['max_wait']:9.1f} {r['mean_queue']:11.1f} {r['switches']:9d}")
