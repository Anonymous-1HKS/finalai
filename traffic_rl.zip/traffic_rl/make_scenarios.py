import os

ROUTES = """<routes>
    <vType id="car" accel="2.6" decel="4.5" length="5" maxSpeed="16"/>
    <route id="ns" edges="north_in south_out"/>
    <route id="sn" edges="south_in north_out"/>
    <route id="ew" edges="east_in  west_out"/>
    <route id="we" edges="west_in  east_out"/>
    <route id="nw" edges="north_in west_out"/>
    <route id="se" edges="south_in east_out"/>
    <route id="en" edges="east_in  north_out"/>
    <route id="ws" edges="west_in  south_out"/>
    <flow id="f_ns" type="car" route="ns" begin="0" end="3600" vehsPerHour="{major}"/>
    <flow id="f_sn" type="car" route="sn" begin="0" end="3600" vehsPerHour="{major}"/>
    <flow id="f_ew" type="car" route="ew" begin="0" end="3600" vehsPerHour="{minor}"/>
    <flow id="f_we" type="car" route="we" begin="0" end="3600" vehsPerHour="{minor}"/>
    <flow id="f_nw" type="car" route="nw" begin="0" end="3600" vehsPerHour="{turn}"/>
    <flow id="f_se" type="car" route="se" begin="0" end="3600" vehsPerHour="{turn}"/>
    <flow id="f_en" type="car" route="en" begin="0" end="3600" vehsPerHour="{turn}"/>
    <flow id="f_ws" type="car" route="ws" begin="0" end="3600" vehsPerHour="{turn}"/>
</routes>
"""

CONFIG = """<configuration>
    <input>
        <net-file value="intersection.net.xml"/>
        <route-files value="{routes}"/>
    </input>
    <time>
        <begin value="0"/>
        <end value="3600"/>
    </time>
</configuration>
"""

SCENARIOS = {
    "training":  dict(major=1800, minor=300,  turn=150),   # what the agent trained on
    "balanced":  dict(major=1000, minor=1000, turn=150),   # no busy axis
    "reversed":  dict(major=300,  minor=1800, turn=150),   # busy axis swapped
    "heavy":     dict(major=2000, minor=700,  turn=200),   # more traffic than trained on
    "light":     dict(major=600,  minor=200,  turn=100),   # much quieter
}

os.makedirs("sumo_files/scenarios", exist_ok=True)

for name, demand in SCENARIOS.items():
    rou = f"scenarios/{name}.rou.xml"
    open(f"sumo_files/{rou}", "w").write(ROUTES.format(**demand))
    open(f"sumo_files/scenarios/{name}.sumocfg", "w").write(
        CONFIG.format(routes=f"{name}.rou.xml"))

import shutil
shutil.copy("sumo_files/intersection.net.xml",
            "sumo_files/scenarios/intersection.net.xml")

print("wrote", len(SCENARIOS), "scenarios")
