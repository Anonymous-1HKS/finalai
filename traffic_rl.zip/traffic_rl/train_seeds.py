import os, sys, time
import xml.etree.ElementTree as ET

from agent import DQNAgent
from env import TrafficEnv

SEEDS = [0, 1, 2, 3, 4]
EPISODES = 60
REWARD_SCALE = 100.0

os.makedirs("results/seeds", exist_ok=True)

for seed in SEEDS:
    print(f"\n=== seed {seed} ===", flush=True)
    env = TrafficEnv(tripinfo="results/train_trip.xml", randomize=True)
    agent = DQNAgent(seed=seed)
    history = []

    for episode in range(1, EPISODES + 1):
        start = time.time()
        obs, _ = env.reset(seed=seed * 1000 + episode)
        done = False
        while not done:
            action = agent.act(obs)
            next_obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            agent.remember(obs, action, reward / REWARD_SCALE, next_obs, float(done))
            agent.learn()
            obs = next_obs
        env.close()

        waits = [float(t.get("waitingTime")) for t in
                 ET.parse("results/train_trip.xml").getroot().findall("tripinfo")]
        wait = sum(waits) / len(waits)
        history.append(wait)
        print(f"  ep {episode:3d}  mean wait {wait:6.1f}  "
              f"({time.time()-start:.0f}s)", flush=True)

    agent.save(f"results/seeds/agent_seed{seed}.pt")
    with open(f"results/seeds/history_seed{seed}.txt", "w") as f:
        for i, w in enumerate(history, 1):
            f.write(f"{i}\t{w:.2f}\n")

print("\nall seeds trained")
