import os, statistics
import xml.etree.ElementTree as ET

from agent import DQNAgent
from env import TrafficEnv

SCENARIOS = ["training", "balanced", "reversed", "heavy", "light"]
SEEDS = [0, 1, 2, 3, 4]


class FixedTime:
    name = "Fixed time 25/10"
    def __init__(self): self.action, self.counter = 0, 0
    def act(self, obs):
        self.counter += 1
        limit = 5 if self.action == 0 else 2
        if self.counter >= limit:
            self.action, self.counter = 1 - self.action, 0
        return self.action


class Greedy:
    name = "Greedy"
    def act(self, obs):
        return 0 if obs[0] + obs[1] >= obs[2] + obs[3] else 1


def run(controller, scenario, tag):
    tp = f"results/eval_{scenario}_{tag}.xml"
    env = TrafficEnv(config=f"sumo_files/scenarios/{scenario}.sumocfg", tripinfo=tp)
    obs, _ = env.reset()
    done = False
    while not done:
        obs, r, term, trunc, _ = env.step(controller.act(obs))
        done = term or trunc
    env.close()
    w = [float(t.get("waitingTime")) for t in ET.parse(tp).getroot().findall("tripinfo")]
    return sum(w) / len(w), len(w)


rows = {}
print(f"{'scenario':<12}{'controller':<20}{'mean wait':>18}{'vehicles':>10}")
print("-" * 62)

for scenario in SCENARIOS:
    f_wait, f_veh = run(FixedTime(), scenario, "fixed")
    g_wait, g_veh = run(Greedy(), scenario, "greedy")

    dqn_waits, dqn_vehs = [], []
    for seed in SEEDS:
        agent = DQNAgent()
        agent.load(f"results/seeds/agent_seed{seed}.pt")
        class Wrapped:
            name = "DQN"
            def act(self, obs): return agent.act(obs, explore=False)
        w, v = run(Wrapped(), scenario, f"dqn{seed}")
        dqn_waits.append(w); dqn_vehs.append(v)

    mean = statistics.mean(dqn_waits)
    sd = statistics.stdev(dqn_waits) if len(dqn_waits) > 1 else 0.0

    print(f"{scenario:<12}{'Fixed time':<20}{f_wait:12.1f}{'':>6}{f_veh:10d}")
    print(f"{'':<12}{'Greedy':<20}{g_wait:12.1f}{'':>6}{g_veh:10d}")
    print(f"{'':<12}{'DQN (5 seeds)':<20}{mean:8.1f} ± {sd:4.1f}{'':>4}"
          f"{statistics.mean(dqn_vehs):10.0f}")
    print()
    rows[scenario] = (f_wait, g_wait, mean, sd)

with open("results/seed_summary.txt", "w") as f:
    f.write("scenario\tfixed\tgreedy\tdqn_mean\tdqn_sd\n")
    for k, (a, b, c, d) in rows.items():
        f.write(f"{k}\t{a:.2f}\t{b:.2f}\t{c:.2f}\t{d:.2f}\n")
print("wrote results/seed_summary.txt")
