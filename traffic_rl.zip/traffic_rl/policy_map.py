import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from agent import DQNAgent
from env import MAX_QUEUE, MAX_SINCE_SWITCH

AGENT_PATH = "results/seeds/agent_seed0.pt"
GRID = 16                      # queue values from 0 to 30, per axis
SINCE_SWITCH = 15.0            # seconds since the last switch


def build_obs(ns_queue, ew_queue, current_action):
    q = [ns_queue / 2, ns_queue / 2, ew_queue / 2, ew_queue / 2]
    q = [min(x / MAX_QUEUE, 1.0) for x in q]
    phase = [1.0, 0.0] if current_action == 0 else [0.0, 1.0]
    since = min(SINCE_SWITCH / MAX_SINCE_SWITCH, 1.0)
    return np.array(q + phase + [since], dtype=np.float32)


agent = DQNAgent()
agent.load(AGENT_PATH)

queues = np.linspace(0, 30, GRID)
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

for panel, current in enumerate([0, 1]):
    advantage = np.zeros((GRID, GRID))
    for i, ns in enumerate(queues):
        for j, ew in enumerate(queues):
            q = agent.q_values(build_obs(ns, ew, current))
            advantage[i, j] = q[0] - q[1]      # positive means it prefers north/south

    ax = axes[panel]
    im = ax.imshow(advantage, origin="lower", cmap="RdBu",
                   vmin=-abs(advantage).max(), vmax=abs(advantage).max(),
                   extent=[0, 30, 0, 30], aspect="auto")
    ax.contour(queues, queues, advantage, levels=[0], colors="black", linewidths=1.5)
    ax.set_xlabel("East/west queue (vehicles)")
    ax.set_ylabel("North/south queue (vehicles)")
    ax.set_title(f"Currently green: {'north/south' if current == 0 else 'east/west'}")
    fig.colorbar(im, ax=ax, label="prefers north/south  <-->  prefers east/west")

plt.tight_layout()
plt.savefig("results/figures/policy_map.png", dpi=150)
print("wrote results/figures/policy_map.png")

for current in [0, 1]:
    print(f"\ncurrently green: {'north/south' if current == 0 else 'east/west'}")
    print("  (rows = north/south queue, columns = east/west queue, 0 to 30)")
    print("  N = agent chooses north/south,  E = agent chooses east/west\n")
    for ns in reversed(np.linspace(0, 30, 11)):
        row = ""
        for ew in np.linspace(0, 30, 11):
            q = agent.q_values(build_obs(ns, ew, current))
            row += " N" if q[0] >= q[1] else " E"
        print(f"  {ns:4.0f} |{row}")
    print("       " + "".join(f"{v:3.0f}" for v in np.linspace(0, 30, 11)))
